﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using PTr.Data;
using PTr.Models;

namespace PTr.Controllers
{
    public class WorkStatsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public WorkStatsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: WorkStats
        public async Task<IActionResult> Index()
        {
            var workStats = await _context.Task
                .Include(t => t.TaskType)
                .Include(t => t.WorkSession)
                .Select(t => new WorkStat
                {
                    Id = t.Id,
                    TaskTypeId = t.TaskTypeId,
                    TaskType = t.TaskType,
                    NumberOfHoursWorked = t.Hours * t.Days,
                    WorkMoney = t.Hours * t.Days * t.Money
                })
                .ToListAsync();

            return View(workStats);
        }

        // GET: WorkStats/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var workStat = await _context.WorkStat
                .Include(w => w.TaskType)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (workStat == null)
            {
                return NotFound();
            }

            return View(workStat);
        }

        // GET: WorkStats/Create
        public IActionResult Create()
        {
            ViewData["TaskTypeId"] = new SelectList(_context.TaskType, "Id", "Id");
            return View();
        }
        [Authorize]
        // POST: WorkStats/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,TaskTypeId,NumberOfHoursWorked,WorkMoney")] WorkStat workStat)
        {
            if (ModelState.IsValid)
            {
                _context.Add(workStat);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["TaskTypeId"] = new SelectList(_context.TaskType, "Id", "Id", workStat.TaskTypeId);
            return View(workStat);
        }
        [Authorize]
        // GET: WorkStats/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var workStat = await _context.WorkStat.FindAsync(id);
            if (workStat == null)
            {
                return NotFound();
            }
            ViewData["TaskTypeId"] = new SelectList(_context.TaskType, "Id", "Id", workStat.TaskTypeId);
            return View(workStat);
        }

        // POST: WorkStats/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,TaskTypeId,NumberOfHoursWorked,WorkMoney")] WorkStat workStat)
        {
            if (id != workStat.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(workStat);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!WorkStatExists(workStat.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["TaskTypeId"] = new SelectList(_context.TaskType, "Id", "Id", workStat.TaskTypeId);
            return View(workStat);
        }
        [Authorize]
        // GET: WorkStats/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var workStat = await _context.WorkStat
                .Include(w => w.TaskType)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (workStat == null)
            {
                return NotFound();
            }

            return View(workStat);
        }

        // POST: WorkStats/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var workStat = await _context.WorkStat.FindAsync(id);
            if (workStat != null)
            {
                _context.WorkStat.Remove(workStat);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool WorkStatExists(int id)
        {
            return _context.WorkStat.Any(e => e.Id == id);
        }
    }
}
