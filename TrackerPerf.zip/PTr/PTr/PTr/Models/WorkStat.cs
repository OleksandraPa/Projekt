﻿using System.ComponentModel.DataAnnotations;

namespace PTr.Models
{
    public class WorkStat
    {
        public int Id { get; set; }

        [Display(Name = "Praca jaką wykonujesz")]
        public int TaskTypeId { get; set; }
        [Display(Name = "Praca jaką wykonujesz")]
        public virtual TaskType? TaskType { get; set; }
        [Display(Name = "Numer przepracowanych godzin")]
        //[Range(0, int.MaxValue, ErrorMessage = "Liczba godzin musi być dodatnia.")]
        public int NumberOfHoursWorked { get; set; }
        public int WorkMoney { get; set; }
    }
}
